
<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('common.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="form-v8">
<div class="page-content">
<div class="form-v8-content">

	<div class="form-left">	
	<img src="images/form-v8.jpg" alt="form">
	</div>
	<div class="form-right">


	<?php if(session('message')): ?>
	<div class="alert alert-success" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php echo e(session('message')); ?>

	</div>
	<?php endif; ?>



	<?php if(session('failed')): ?>
	<div class="alert alert-danger" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php echo e(session('failed')); ?>

	</div>
	<?php endif; ?>

	<div class="tab">
		<div class="tab-inner">
		<button class="tablinks" onclick="openCity(event, 'sign-in')" id="defaultOpen">Sign In</button>
		</div>
	</div>

	<form class="form-detail" action="<?php echo e(url('post-login')); ?>" method="post">
	<?php echo e(csrf_field()); ?>

		<div class="tabcontent" id="sign-in">
			<div class="form-row">
			<label class="form-row-inner">
			<input type="text" name="email" class="input-text" required>
			<span class="label">E-Mail</span>
			<span class="border"></span>
				<?php if($errors->has('email')): ?>
				<span class="error"><?php echo e($errors->first('email')); ?></span>
				<?php endif; ?> 
			</label>
			</div>
			<div class="form-row">
			<label class="form-row-inner">
			<input type="password" name="password" class="input-text" required>
			<span class="label">Password</span>
			<span class="border"></span>
				<?php if($errors->has('password')): ?>
				<span class="error"><?php echo e($errors->first('password')); ?></span>
				<?php endif; ?>
			</label>
			</div>
			
			<div class="form-row-last">
			<input type="submit" class="register" value="Sign In">
			</div>
			<a class="small" href="<?php echo e(route('forgetpassword')); ?>" style="color:white;">Forgot Password?</a>
		</div>
	</form>
	
</div>
</div>
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>


<style>
.form-v8-content {
    background: #3d5983;
}
</style><?php /**PATH /var/www/html/spkLaravel/resources/views/login.blade.php ENDPATH**/ ?>