<!DOCTYPE html>
<html lang="en">
<head>

  <?php echo $__env->make('backend.common.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php echo $__env->make('backend.common.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('backend.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Items</h1>
          </div>
          <div class="col-sm-6">
          </div> 
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-2">
          
        </div>
        <div class="col-md-8">
        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
          <button type="button" class="close" data-dismiss="alert">×</button>
          <?php echo e(session('status')); ?>

        </div>
        <?php elseif(session('failed')): ?>
        <div class="alert alert-danger" role="alert">
          <button type="button" class="close" data-dismiss="alert">×</button>
          <?php echo e(session('failed')); ?>

        </div>
        <?php endif; ?>
          <div class="card card-outline card-info">
          <form action="<?php echo e(url('/admin/add-item-post')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

              <div class="card-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Item Name</label>
                  <input type="text" class="form-control" name="name" placeholder="Enter name">
                  <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <textarea id="summernote" name="description">
                    Place <em>some</em> <u>text</u> <strong>here</strong>
                  </textarea>
                  <?php if($errors->has('description')): ?>
                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Price</label>
                  <input type="text" class="form-control" name="price" placeholder="Price">
                  <?php if($errors->has('price')): ?>
                    <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                  <?php endif; ?>
                </div>
               
                <div class="form-group">
                  <label for="exampleInputPassword1">Stock</label>
                  <input type="text" class="form-control" name="stock" placeholder="Stock">
                  <?php if($errors->has('stock')): ?>
                    <span class="text-danger"><?php echo e($errors->first('stock')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="row"> 
                  <div class="col-md-6">
                    <div class="form-group">
                    <label for="exampleInputPassword1">Status</label>
                          <select class="form-control" name="status">
                            <option value="available" >Available</option>
                            <option value="outofstock" >Out of Stock</option>
                          </select>
                          <?php if($errors->has('status')): ?>
                            <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                          <?php endif; ?>
                    </div>
                  </div>
                  <!-- <div class="col-md-6">
                    <div class="form-group">
                    <label for="exampleInputPassword1">Items Unique Id</label>
                    <input type="text" class="form-control" placeholder="Auto-generation-Item-ID" readonly>
                    </div>
                  </div> -->
                </div>

              </div>
              <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>

          </div>
        </div>
        <div class="col-md-2"></div>
        <!-- /.col-->
      </div>
      <!-- ./row -->

      <!-- ./row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php echo $__env->make('backend.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php echo $__env->make('backend.common.footer-bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>

  $('#summernote').summernote({
  height: 150,   //set editable area's height
  codemirror: { // codemirror options
    theme: 'monokai'
  }
});
  
</script>
</body>
</html>
<?php /**PATH /var/www/html/spkLaravel/resources/views/backend/add-items.blade.php ENDPATH**/ ?>