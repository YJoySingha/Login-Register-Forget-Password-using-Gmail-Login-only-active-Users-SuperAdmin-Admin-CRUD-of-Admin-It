<footer class="main-footer">
    <strong>Copyright &copy; 2021-2022 <a href="#">yjoy-chandra-singha</a>.</strong>
    All rights reserved.
  </footer><?php /**PATH /var/www/html/spkLaravel/resources/views/backend/common/footer.blade.php ENDPATH**/ ?>