<!DOCTYPE html>
<html lang="en">
<head>

  <?php echo $__env->make('backend.common.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php echo $__env->make('backend.common.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('backend.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Admin</h1>
          </div>
          <div class="col-sm-6">
          </div> 
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-2">
          
        </div>
        <div class="col-md-8">

        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
          <button type="button" class="close" data-dismiss="alert">×</button>
          <?php echo e(session('status')); ?>

        </div>
        <?php elseif(session('failed')): ?>
        <div class="alert alert-danger" role="alert">
          <button type="button" class="close" data-dismiss="alert">×</button>
          <?php echo e(session('failed')); ?>

        </div>
        <?php endif; ?>

          <div class="card card-outline card-info">
            <form action="<?php echo e(url('/admin/update-admin/'. $user['id'] )); ?>" method="post">
            <?php echo e(csrf_field()); ?>

              <div class="card-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Admin Name</label>
                  <input type="text" class="form-control" name="name" value="<?php echo e($user['name']); ?>" placeholder="Enter email">
                  <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Phone</label>
                  <input type="text" class="form-control" name="phone" value="<?php echo e($user['phone']); ?>" placeholder="Password">
                  <?php if($errors->has('phone')): ?>
                    <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                  <?php endif; ?>
                </div>
               
                <div class="form-group">
                  <label for="exampleInputPassword1">Email-Id</label>
                  <input type="text" class="form-control" name="email" value="<?php echo e($user['email']); ?>" placeholder="Password">
                  <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" name="password" value="<?php echo e($user['password']); ?>" placeholder="Password">
                  <?php if($errors->has('password')): ?>
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Address</label>
                  <textarea class="form-control" rows="3" name="address"><?php echo e($user['address']); ?></textarea>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                    <label for="exampleInputPassword1">Role</label>
                          <select class="form-control" name="role">
                            <option value="sadmin" <?php echo ($user['role']=='sadmin') ? 'selected' : '' ?>> Super Admin</option>
                            <option value="admin" <?php echo ($user['role']=='admin') ? 'selected' : '' ?> > Admin</option>
                          </select>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                    <label for="exampleInputPassword1">Employee Id Auto-generate</label>
                    <input type="text" class="form-control" value="<?php echo e($user['employeeId']); ?>" placeholder="Auto-generation-ID" readonly>
                    </div>
                  </div>
                </div>

              </div>
              <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>

          </div>
        </div>
        <div class="col-md-2"></div>
        <!-- /.col-->
      </div>
      <!-- ./row -->

      <!-- ./row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php echo $__env->make('backend.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php echo $__env->make('backend.common.footer-bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH /var/www/html/spkLaravel/resources/views/backend/edit-admin.blade.php ENDPATH**/ ?>