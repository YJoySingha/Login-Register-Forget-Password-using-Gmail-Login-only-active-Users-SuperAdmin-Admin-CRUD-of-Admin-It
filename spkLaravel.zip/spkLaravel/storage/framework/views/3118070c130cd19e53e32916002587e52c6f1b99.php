<meta charset="utf-8">
<title>SPK-Login-Register</title>

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/sourcesanspro-font.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />




<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<meta name="robots" content="noindex, follow">
<?php /**PATH /var/www/html/spkLaravel/resources/views/common/head.blade.php ENDPATH**/ ?>