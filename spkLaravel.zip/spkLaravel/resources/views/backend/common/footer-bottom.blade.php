
<script src="{{ asset('backend/isset/js/jquery.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/bootstrap.bundle.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/jquery.overlayScrollbars.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/adminlte.js') }}"></script>

<script src="{{ asset('backend/isset/js/jquery.mousewheel.js') }}"></script>

<script src="{{ asset('backend/isset/js/raphael.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/jquery.mapael.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/usa_states.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/Chart.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/demo.js') }}"></script>

<script src="{{ asset('backend/isset/js/dashboard2.js') }}"></script>


<script src="{{ asset('backend/isset/js/summernote-bs4.min.js') }}"></script>


<script src="{{ asset('backend/isset/js/jquery.dataTables.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/dataTables.bootstrap4.min.js') }}"></script>

<script src="{{ asset('backend/isset/js/dataTables.responsive.min.js') }}"></script>

